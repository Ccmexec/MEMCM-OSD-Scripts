﻿# Script to write OSD Complete and register the Schedule Task that will monitor HYbrid Join, MDM enrollment, Defender for endpoint omboarding.
# Jorgen@ccmexec.com

$logfilepath="C:\Windows\Temp\DefenderOnboarding.log"

function WriteToLogFile ($message)
{
$message +" - "+ (Get-Date).ToString() >> $logfilepath
}

WriteToLogFile "OSD Complete"
Copy-Item -Path $PSScriptRoot'\WaitforOnboard.ps1' -Destination $env:Windir'\Temp'
Register-ScheduledTask -Xml (get-content $PSScriptRoot\WaitforOnboarding.xml | out-string) -TaskName "WaitforOnboarding"
